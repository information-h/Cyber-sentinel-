from monitor.file_watcher import watch_folder

if __name__ == "__main__":
    folder_to_watch = "./watch_folder"
    watch_folder(folder_to_watch)
