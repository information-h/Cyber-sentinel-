# CyberSentinel - Real-Time Threat Detection

A simple Python-based project to detect suspicious files, trace origin, detect code language, and delete automatically.

## Features
- Real-time folder monitoring
- Detects script/executable files
- Identifies programming language
- Deletes harmful files automatically
- Logs report in JSON format

## Usage
1. Put files inside `watch_folder/`
2. Run: `python main.py`
