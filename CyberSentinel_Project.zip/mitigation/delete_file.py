import os

def delete_file(path):
    try:
        os.remove(path)
        print(f"[🗑️] File deleted: {path}")
        return True
    except Exception as e:
        print(f"[❌] Failed to delete: {e}")
        return False
