import json
import os
from datetime import datetime

def log_threat(filename, lang, ip_info, deleted):
    log = {
        "filename": filename,
        "language": lang,
        "source_ip": ip_info["source_ip"],
        "country": ip_info["country"],
        "action": "Deleted" if deleted else "Failed to delete",
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

    os.makedirs("report/logs", exist_ok=True)
    with open("report/logs/threat_log.json", "a") as f:
        f.write(json.dumps(log) + "\n")
    print(f"[📄] Threat logged: {filename}")
