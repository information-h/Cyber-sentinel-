import os
import time
from analysis.lang_detect import detect_language
from analysis.ip_trace import trace_ip_from_filename
from mitigation.delete_file import delete_file
from report.logger import log_threat

def watch_folder(folder):
    print(f"[INFO] Watching folder: {folder}")
    seen_files = set(os.listdir(folder))

    while True:
        current_files = set(os.listdir(folder))
        new_files = current_files - seen_files

        for file in new_files:
            filepath = os.path.join(folder, file)
            print(f"[⚠️] New file detected: {file}")

            lang = detect_language(filepath)
            ip_info = trace_ip_from_filename(file)

            deleted = delete_file(filepath)
            log_threat(file, lang, ip_info, deleted)

        seen_files = current_files
        time.sleep(5)
