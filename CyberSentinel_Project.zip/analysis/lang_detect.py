import os

def detect_language(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()

        if "import os" in content or "def " in content:
            return "Python"
        elif "#include" in content:
            return "C/C++"
        elif "public static void main" in content:
            return "Java"
        elif "<script>" in content:
            return "JavaScript"
        else:
            return "Unknown"
    except:
        return "Binary/Executable"
