def trace_ip_from_filename(filename):
    import re
    match = re.search(r'(\d{1,3}(?:\.\d{1,3}){3})', filename)
    if match:
        ip = match.group(1)
        return {
            "source_ip": ip,
            "country": "Unknown"
        }
    return {"source_ip": "Unknown", "country": "Unknown"}
